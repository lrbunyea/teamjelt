*********************************************************
*                Red Light - Greeen Light               *
*********************************************************

//File Structure (Subject to change depending on implementation)
- Assets
	- Scripts
		- WorldManager - Controls the flow of the game, through Menu, Setup, and Play
		- PlayerManager - Stores the players and manages how the game interacts with them
		- StateManager - Manages the In-game State between Red Light and Green Light
		- Player - Stores a player ID and Joycon
		- JoyconLib - All Data associated with the Joycons
