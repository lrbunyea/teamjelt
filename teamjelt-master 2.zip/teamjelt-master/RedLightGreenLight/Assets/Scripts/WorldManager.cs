/**using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WorldManager : MonoBehaviour
{
    #region Variables
    public StateManager.State currentState;
    #endregion

    #region Unity API
    void Start()
    {
        
    }

    void Update()
    {
        //Button presses here...
    }
    #endregion
}**/
